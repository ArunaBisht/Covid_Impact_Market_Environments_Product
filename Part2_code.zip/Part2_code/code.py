import streamlit as st
import time
import numpy as np
import yfinance as yf
import questionary
import plotly.express as px
import hvplot.pandas
import pandas as pd
from PIL import Image

image = Image.open('investment.PNG')
st.image(image, caption='Investment deck' , width= 300, len = 200, channel = 'RGB')

#city = 'San Jose'

city = 'Los Angeles'

st.subheader("What city is best to invest in ?")
st.write("\nAs per yours demographic selection {} city is best to invest in".format(city))

st.subheader("Please submit this questionaire to find what are your options in this city ?. Why this city is best to invest in ? ")
answer = st.selectbox("Do you want to buy or sell?", ('buy', 'sell'))

if (answer == 'buy'):
    price = st.slider('What price range you are looking for to filter listings ?', 0.0, 1000000.0, (100000.0, 500000.0))
    min_price = price[0]
    max_price = price[1]

    buyer_price = st.number_input('Is there a specific price for which yours loan would be approved? ')

    year_built = st.slider('What range of year built you are looking for?', 1850, 2021, (1900, 2021))
    min_year_built = year_built[0]
    max_year_built = year_built[1]

    sqaure_feet = st.slider('What range of square feet (sqft) area you are looking for?', 0, 10000, (500, 2000))
    min_sqaure_feet = sqaure_feet[0]
    max_sqaure_feet = sqaure_feet[1]

    property_type = st.multiselect( "Please select the property type?",  ["condo", "single_familiy", "multi_family"])

    mortgage = st.number_input('What is the monthly mortgage you are planning to pay?')
    
    
real_estate_sold = pd.read_csv("Real_estate\\list_sold_data_1.csv")

 # counter to count the listing in each cities
la_count, santa_count,  Sacramento_count , SF_count = 0, 0 , 0 , 0
column_list = []
for column_name, column in real_estate_sold.transpose().iterrows():
    column_list.append(column_name)

st.subheader("As per your criteria, following are the available listings for {} city.".format(city))

#iterrate through each row of datasets to match it with user parameter
for index, row in real_estate_sold.iterrows():
    if (float(min_year_built) <= row['year_built'] <= float(max_year_built)) and (row['address.city'] == city) and (float(min_price) <= row['price'] <= float(max_price)) and (row['prop_type'] in property_type) and (float(min_sqaure_feet) <= row['building_size.size'] <= float(max_sqaure_feet)):
        santa_count = santa_count + 1
        st.write("City has this property type {0} built in year {1} and price is {2}".format(row['prop_type'], row['year_built'],row['price']))
       

#print number of COVID cases in each city 
covid_cases = pd.read_csv("covid_data\\statewide_cases_3.csv")
covid_cases_new = covid_cases.groupby('county').sum('totalcountconfirmed')

# extract unique lines of county from COVID dataset
y = covid_cases['county'].unique()
y1 = y.tolist()
y1.sort()
covid_cases_new1 = covid_cases_new.assign(county_data = y1  )

# iterrate through each row of covid dataset to match with given county and print confirmed covid cases
santa_confirmed = 0
LA_confirmed  = 0
sacramento_confirmed = 0
SF_confirmed = 0

for index, row in covid_cases_new1.iterrows():
    if (row['county_data'] == 'Santa Clara'):
        #print("Total number of San jose confirmed Covid cases till date is {} ".format(row['totalcountconfirmed']))
        santa_confirmed = row['totalcountconfirmed']
    if (row['county_data'] == 'Los Angeles'):
        #print("Total number of {} confirmed Covid cases till date is {} ".format(row['county_data'],row['totalcountconfirmed']))
        LA_confirmed = row['totalcountconfirmed']
    if (row['county_data'] == 'Sacramento'):
        #print("Total number of {} confirmed Covid cases till date is {} ".format(row['county_data'],row['totalcountconfirmed']))
        sacramento_confirmed = row['totalcountconfirmed']
    if (row['county_data'] == 'San Francisco'):
        #print("Total number of {} confirmed Covid cases till date is {} ".format(row['county_data'],row['totalcountconfirmed']))
        SF_confirmed = row['totalcountconfirmed']

    min_covid = {'santa': santa_confirmed, 'LA': LA_confirmed, 'sacramento': sacramento_confirmed, 'SF': SF_confirmed}

st.subheader("The reason why this city is good to invest in ?")


#PART 2 - why chosen city is the best best for the buyer?

santa_rent=0
LA_rent = 0 
SF_rent = 0
SA_rent = 0
counter_rent = 0
counter_LA_rent = 0
counter_SF_rent = 0
counter_SA_rent = 0

# Whether 'Average rent' from the historical data great is greater then user's mortgage input data ?
real_estate_rent = pd.read_csv("Real_estate\\list_for_rent_data.csv")
for index, row in real_estate_rent.iterrows():
    if (row['address.city']) == 'Santa Clarita':
        santa_rent = santa_rent + row['community.price_min']
        counter_rent = counter_rent+1
    if (row['address.city']) == 'Los Angeles':
        LA_rent = LA_rent + row['community.price_min']
        counter_LA_rent = counter_LA_rent + 1
    if (row['address.city']) == 'San Francisco':
        SF_rent = SF_rent + row['community.price_min']
        counter_SF_rent = counter_SF_rent + 1
    if (row['address.city']) == 'Sacramento':
        SA_rent = SA_rent + row['community.price_min']
        counter_SA_rent = counter_SA_rent + 1

santa_rent_avg = santa_rent/ counter_rent
LA_rent_avg = LA_rent/ counter_LA_rent
SF_rent_avg = SF_rent/ counter_SF_rent
SA_rent_avg = SA_rent/ counter_SA_rent

avg_rent = {'San jose': santa_rent_avg, 'Los Angeles': LA_rent_avg, 'Sacramento': SA_rent_avg, 'San Francisco': SF_rent_avg}

for key in avg_rent.keys() :
    if (key == city):
        if (avg_rent[key] > int(mortgage)):
            st.write("\n Average historical rent is more then user's input mortgage, so it's a good buy")


# Whether 'Average prices' from the historical data is greater then users input price ?

santa_price, LA_price , SF_price , SA_price = 0 , 0 , 0 , 0
counter_price , counter_LA_price , counter_SF_price , counter_SA_price = 0 , 0 , 0 , 0

real_estate_sold = pd.read_csv("Real_estate\\list_sold_data_1.csv")
for index, row in real_estate_sold.iterrows():
    if (row['address.city']) == 'Santa Clara':
        santa_price = santa_price + row['price']
        counter_price = counter_price + 1
    if (row['address.city']) == 'Los Angeles':
        LA_price = LA_price + row['price']
        counter_LA_price = counter_LA_price + 1
    if (row['address.city']) == 'San Francisco':
        SF_price = SF_price + row['price']
        counter_SF_price = counter_SF_price + 1
    if (row['address.city']) == 'Sacramento':
        SA_price = SA_price + row['price']
        counter_SA_price = counter_SA_price + 1

santa_price_avg = santa_price/ counter_price
LA_price_avg = LA_price/ counter_LA_price
SF_price_avg = SF_price/ counter_SF_price
SA_price_avg = SA_price/ counter_SA_price

avg_price = {'San jose': santa_price_avg, 'Los Angeles': LA_price_avg, 'Sacramento': SA_price_avg, 'San Francisco': SF_price_avg}

for key in avg_price.keys() :
    if (key == city):
        if (avg_price[key] > int(buyer_price)):
            st.write("\nAverage historical price is more then user's input price, so it's a good buy") #.format(key))

st.subheader("General note - ")

covid_cases = {'San jose': santa_confirmed, 'Los Angeles': LA_confirmed, 'Sacramento': sacramento_confirmed, 'San Francisco': SF_confirmed}
   
for key in covid_cases.keys() :
    if (key == city):
        st.write("\nNumber of covid cases in this City is  1135450 ") #.format(covid_cases[key]))
